#include <stdio.h>

int main()
{
    int bilanganBulat;
    scanf("%d", &bilanganBulat);
    printf("%x", bilanganBulat);
    return 0;
}