#include <stdio.h>

int main (){
    int umur;
    scanf("%d",&umur);
    printf("Selamat ulang tahun yang ke %d yaaa!",umur);
    return 0;
}