#include <stdio.h>

int main()
{
    int angka1, angka2, sum;
    printf("Enter first integer\n");
    scanf("%d", &angka1);
    printf("Enter seconf integer\n");
    scanf("%d", &angka2);
    sum = angka1 + angka2;
    printf("Sum is %d", sum);
    return 0;
}